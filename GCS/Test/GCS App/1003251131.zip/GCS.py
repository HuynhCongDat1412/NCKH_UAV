import sys
import json
import time
from datetime import datetime
import os
import serial
import serial.tools.list_ports
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QWidget,
    QLabel, QComboBox, QPushButton, QDoubleSpinBox, QSpinBox,
    QGroupBox, QFormLayout, QTextEdit, QInputDialog, QLineEdit
)
from PyQt5.QtCore import QTimer, QThread, pyqtSignal, Qt, QSettings
from PyQt5.QtGui import QFont

CONFIG_FILE = "gcs_config.json"

class SerialThread(QThread):
    data_received = pyqtSignal(str)
    def __init__(self, port):
        super().__init__()
        self.port = port
        self.running = True
    def run(self):
        while self.running and self.port.is_open:
            try:
                if self.port.in_waiting:
                    line = self.port.readline().decode('utf-8', errors='ignore').strip()
                    if line: self.data_received.emit(line)
            except: pass
    def stop(self):
        self.running = False

class GCSWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.serial = None
        self.thread = None
        self.configs = self.load_configs()
        self.settings = QSettings("DroneGCS", "UI")
        self.scale_percent = self.settings.value("scale", 100, type=int)
        self.dark_mode = self.settings.value("dark_mode", False, type=bool)
        self.initUI()
        self.apply_scale()
        self.apply_theme()

    def initUI(self):
        self.setWindowTitle("Drone GCS - Ground Control Station")
        self.setGeometry(100, 100, 1450, 800)
        central = QWidget()
        main_layout = QVBoxLayout()
        central.setLayout(main_layout)
        self.setCentralWidget(central)

        # === TOP BAR ===
        top_layout = QHBoxLayout()
        self.port_cb = QComboBox(); self.port_cb.setMinimumWidth(120)
        self.baud_cb = QComboBox(); self.baud_cb.addItems(["115200", "57600", "9600"])
        self.baud_cb.setCurrentText("115200")
        self.conn_btn = QPushButton("Connect")
        self.conn_btn.clicked.connect(self.toggle_connection)
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(self.refresh_ports)
        self.status_label = QLabel("Disconnected")
        self.status_label.setStyleSheet("color: red; font-weight: bold")

        top_layout.addWidget(QLabel("COM:")); top_layout.addWidget(self.port_cb)
        top_layout.addWidget(QLabel("Baud:")); top_layout.addWidget(self.baud_cb)
        top_layout.addWidget(self.conn_btn); top_layout.addWidget(self.refresh_btn)
        top_layout.addWidget(self.status_label)

        top_layout.addWidget(QLabel("Drone MAC:"))
        self.mac_input = QLineEdit()
        self.mac_input.setPlaceholderText("AA:BB:CC:DD:EE:FF")
        self.mac_input.setFixedWidth(150)
        top_layout.addWidget(self.mac_input)

        top_layout.addStretch()
        self.scale_btn = QPushButton(f"Scale: {self.scale_percent}%")
        self.scale_btn.clicked.connect(self.change_scale)
        self.theme_btn = QPushButton("Dark Mode")
        self.theme_btn.clicked.connect(self.toggle_theme)
        top_layout.addWidget(self.scale_btn); top_layout.addWidget(self.theme_btn)
        main_layout.addLayout(top_layout)

        # === CONTENT ===
        content = QHBoxLayout()

        # LEFT: Telemetry
        left_col = QVBoxLayout()
        tele_box = QGroupBox("Telemetry")
        tele_layout = QFormLayout()
        self.labels = {}
        for key in ["timestamp", "roll", "pitch", "yaw", "battery", "armed", "rssi", "loss"]:
            lbl = QLabel("---"); lbl.setFont(QFont("Segoe UI", 11))
            self.labels[key] = lbl
            tele_layout.addRow(f"{key.replace('_', ' ').title()}:", lbl)
        tele_box.setLayout(tele_layout)
        left_col.addWidget(tele_box)
        content.addLayout(left_col, 2)

        # RIGHT: Tuning + Commands
        right_col = QVBoxLayout()

        # Tuning
        tune_box = QGroupBox("Tuning Parameters")
        tune_layout = QFormLayout()
        self.p_spin = QDoubleSpinBox(); self.p_spin.setRange(0, 100); self.p_spin.setDecimals(3); self.p_spin.setValue(1.5)
        self.i_spin = QDoubleSpinBox(); self.i_spin.setRange(0, 10); self.i_spin.setDecimals(3); self.i_spin.setValue(0.05)
        self.d_spin = QDoubleSpinBox(); self.d_spin.setRange(0, 10); self.d_spin.setDecimals(3); self.d_spin.setValue(0.08)
        self.bank_spin = QSpinBox(); self.bank_spin.setRange(10, 60); self.bank_spin.setValue(30)
        tune_layout.addRow("P:", self.p_spin); tune_layout.addRow("I:", self.i_spin)
        tune_layout.addRow("D:", self.d_spin); tune_layout.addRow("Max Bank (°):", self.bank_spin)

        btn_layout = QHBoxLayout()
        self.send_tune_btn = QPushButton("Send"); self.send_tune_btn.clicked.connect(self.send_tuning)
        self.save_cfg_btn = QPushButton("Save Config"); self.save_cfg_btn.clicked.connect(self.save_current_config)
        btn_layout.addWidget(self.send_tune_btn); btn_layout.addWidget(self.save_cfg_btn)
        tune_layout.addRow(btn_layout)

        cfg_layout = QHBoxLayout()
        self.cfg_combo = QComboBox(); self.cfg_combo.addItems(self.configs.keys())
        self.load_cfg_btn = QPushButton("Load"); self.load_cfg_btn.clicked.connect(self.load_selected_config)
        self.del_cfg_btn = QPushButton("Delete"); self.del_cfg_btn.clicked.connect(self.delete_config)
        cfg_layout.addWidget(QLabel("Config:")); cfg_layout.addWidget(self.cfg_combo)
        cfg_layout.addWidget(self.load_cfg_btn); cfg_layout.addWidget(self.del_cfg_btn)
        tune_layout.addRow(cfg_layout)
        tune_box.setLayout(tune_layout)
        right_col.addWidget(tune_box)

        # Commands
        cmd_box = QGroupBox("Commands")
        cmd_layout = QFormLayout()
        self.mode_cb = QComboBox(); self.mode_cb.addItems(["Manual", "Stabilize", "AltHold", "Loiter", "RTL"])
        cmd_layout.addRow("Mode:", self.mode_cb)

        arm_layout = QHBoxLayout()
        self.arm_btn = QPushButton("ARM"); self.arm_btn.clicked.connect(lambda: self.send_command("ARM"))
        self.disarm_btn = QPushButton("DISARM"); self.disarm_btn.clicked.connect(lambda: self.send_command("DISARM"))
        arm_layout.addWidget(self.arm_btn); arm_layout.addWidget(self.disarm_btn)
        cmd_layout.addRow(arm_layout)

        calib_layout = QHBoxLayout()
        self.calib_gyro_btn = QPushButton("Calib Gyro"); self.calib_gyro_btn.clicked.connect(lambda: self.send_command("CALIB_GYRO"))
        self.calib_acc_btn = QPushButton("Calib Acc"); self.calib_acc_btn.clicked.connect(lambda: self.send_command("CALIB_ACC"))
        calib_layout.addWidget(self.calib_gyro_btn); calib_layout.addWidget(self.calib_acc_btn)
        cmd_layout.addRow(calib_layout)
        cmd_box.setLayout(cmd_layout)
        right_col.addWidget(cmd_box)
        content.addLayout(right_col, 1)
        main_layout.addLayout(content)

        # LOG
        log_box = QGroupBox("UART Log")
        log_layout = QVBoxLayout()
        self.log_text = QTextEdit(); self.log_text.setReadOnly(True); self.log_text.setFont(QFont("Consolas", 9))
        log_layout.addWidget(self.log_text)
        log_box.setLayout(log_layout)
        main_layout.addWidget(log_box, 1)

        self.timer = QTimer(); self.timer.timeout.connect(self.update_ui); self.timer.start(50)
        self.refresh_ports()
        self.load_last_config()

    def load_last_config(self):
        if "default" in self.configs:
            cfg = self.configs["default"]
            self.p_spin.setValue(cfg.get("p", 1.5)); self.i_spin.setValue(cfg.get("i", 0.05))
            self.d_spin.setValue(cfg.get("d", 0.08)); self.bank_spin.setValue(cfg.get("bank", 30))
            self.mac_input.setText(cfg.get("drone_mac", ""))
            self.cfg_combo.setCurrentText("default")

    def save_current_config(self):
        name, ok = QInputDialog.getText(self, "Save Config", "Config name:", text="default")
        if ok and name:
            self.configs[name] = {
                "p": self.p_spin.value(), "i": self.i_spin.value(),
                "d": self.d_spin.value(), "bank": self.bank_spin.value(),
                "drone_mac": self.mac_input.text().strip().upper()
            }
            self.save_configs()
            self.cfg_combo.clear(); self.cfg_combo.addItems(self.configs.keys())
            self.cfg_combo.setCurrentText(name)
            self.log(f"Config '{name}' saved")

    def load_configs(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    return json.load(f)
            except: pass
        return {"default": {"p": 1.5, "i": 0.05, "d": 0.08, "bank": 30, "drone_mac": ""}}

    def save_configs(self):
        with open(CONFIG_FILE, 'w') as f:
            json.dump(self.configs, f, indent=2)

    def connect(self):
        try:
            port = self.port_cb.currentText()
            baud = int(self.baud_cb.currentText())
            self.serial = serial.Serial(port, baud, timeout=1.0)  # Tăng timeout
            self.serial.flushInput()
            self.serial.flushOutput()

            # Gửi CONNECT
            self.serial.write(b"CONNECT\n")
            self.serial.flush()

            # Chờ CONNECT_OK
            response = self.wait_for_response("CONNECT_OK", timeout=2.0)
            if not response:
                self.serial.close()
                self.log("CONNECT failed")
                return

            # Gửi MAC
            mac = self.mac_input.text().strip().upper()
            if not mac or len(mac) != 17:
                self.log("Invalid MAC!")
                self.serial.close()
                return

            self.serial.write(f"MAC:{mac}\n".encode())
            self.serial.flush()

            # Chờ MAC_OK
            if self.wait_for_response("MAC_OK", timeout=2.0):
                self.thread = SerialThread(self.serial)
                self.thread.data_received.connect(self.on_serial_data)
                self.thread.start()
                self.status_label.setText("Connected + MAC OK")
                self.status_label.setStyleSheet("color: green; font-weight: bold")
                self.conn_btn.setText("Disconnect")
                self.log(f"Connected! Drone MAC: {mac}")
            else:
                self.serial.close()
                self.log("MAC pairing failed")

        except Exception as e:
            self.log(f"Error: {e}")
            if self.serial: self.serial.close()

    def wait_for_response(self, expected, timeout=2.0):
        start = time.time()
        while time.time() - start < timeout:
            if self.serial.in_waiting:
                line = self.serial.readline().decode('utf-8', errors='ignore').strip()
                self.log(f"[GCS] {line}")
                if expected in line:
                    return True
            time.sleep(0.01)
        return False

    def disconnect(self):
        if self.thread: self.thread.stop(); self.thread.wait()
        if self.serial: self.serial.close()
        self.status_label.setText("Disconnected"); self.status_label.setStyleSheet("color: red; font-weight: bold")
        self.conn_btn.setText("Connect"); self.log("Disconnected")

    def on_serial_data(self, data):
        self.log(f"[UART] {data}")
        try:
            if data.startswith("{") and data.endswith("}"):
                payload = json.loads(data)
                self.update_telemetry(payload)
        except: pass

    def update_telemetry(self, data):
        ts = datetime.fromtimestamp(data.get("timestamp", 0)/1000).strftime("%d/%m/%y | %H:%M:%S")
        self.labels["timestamp"].setText(ts)
        self.labels["roll"].setText(f"{data.get('roll',0):+.1f}°"); self.set_color(self.labels["roll"], abs(data.get('roll',0)) < 45)
        self.labels["pitch"].setText(f"{data.get('pitch',0):+.1f}°"); self.set_color(self.labels["pitch"], abs(data.get('pitch',0)) < 45)
        self.labels["yaw"].setText(f"{data.get('yaw',0):+.1f}°")
        batt = data.get("battery", 0); percent = int((batt - 10.0)/(12.6-10.0)*100); percent = max(0,min(100,percent))
        self.labels["battery"].setText(f"{batt:.1f}V / {percent}%"); self.set_color(self.labels["battery"], batt > 11.0)
        armed = data.get("armed", False); self.labels["armed"].setText("TRUE" if armed else "FALSE"); self.set_color(self.labels["armed"], not armed)
        rssi = data.get("rssi", -100); self.labels["rssi"].setText(f"{rssi} dBm"); self.set_color(self.labels["rssi"], rssi > -80)
        loss = data.get("loss", 0); self.labels["loss"].setText(f"{loss}%"); self.set_color(self.labels["loss"], loss < 5)

    def set_color(self, label, safe):
        label.setStyleSheet(f"color: {'#2e8b27' if safe else '#dc143c'}; font-weight: bold;")

    def send_tuning(self):
        cmd = {"type": "PID", "p": self.p_spin.value(), "i": self.i_spin.value(), "d": self.d_spin.value(), "max_bank": self.bank_spin.value()}
        self.send_json(cmd); self.log(f"Sent PID: P={cmd['p']}, I={cmd['i']}, D={cmd['d']}")

    def send_command(self, cmd):
        payload = {"type": "CMD", "cmd": cmd}
        self.send_json(payload); self.log(f"Sent: {cmd}")

    def send_json(self, data):
        if self.serial and self.serial.is_open:
            try: self.serial.write((json.dumps(data) + "\n").encode())
            except: self.log("Send failed")

    def toggle_connection(self):
        if self.serial and self.serial.is_open: self.disconnect()
        else: self.connect()

    def change_scale(self):
        scales = [50, 75, 100, 125, 150, 175, 200]
        idx = scales.index(self.scale_percent) if self.scale_percent in scales else 2
        self.scale_percent = scales[(idx + 1) % len(scales)]
        self.scale_btn.setText(f"Scale: {self.scale_percent}%")
        self.settings.setValue("scale", self.scale_percent)
        self.apply_scale()

    def apply_scale(self):
        scale = self.scale_percent / 100.0
        self.setStyleSheet(f"font-size: {10*scale}pt;")
        for w in self.findChildren((QLabel, QPushButton, QComboBox, QDoubleSpinBox, QSpinBox)):
            f = w.font(); f.setPointSize(int(f.pointSize() * scale)); w.setFont(f)
        self.adjustSize()

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.theme_btn.setText("Dark Mode" if self.dark_mode else "Light Mode")
        self.settings.setValue("dark_mode", self.dark_mode)
        self.apply_theme()

    def apply_theme(self):
        if self.dark_mode:
            self.setStyleSheet("background-color: #1e1e1e; color: #ffffff; QGroupBox { border: 1px solid #444; }")
        else:
            self.setStyleSheet("background-color: #f5f5f5; color: #000000; QGroupBox { border: 1px solid #ccc; }")

    def log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_text.append(f"[{ts}] {msg}")
        self.log_text.verticalScrollBar().setValue(self.log_text.verticalScrollBar().maximum())

    def refresh_ports(self):
        self.port_cb.clear()
        for p in serial.tools.list_ports.comports():
            self.port_cb.addItem(p.device)

    def load_selected_config(self):
        name = self.cfg_combo.currentText()
        cfg = self.configs.get(name, {})
        self.p_spin.setValue(cfg.get("p", 1.5)); self.i_spin.setValue(cfg.get("i", 0.05))
        self.d_spin.setValue(cfg.get("d", 0.08)); self.bank_spin.setValue(cfg.get("bank", 30))
        self.mac_input.setText(cfg.get("drone_mac", ""))
        self.log(f"Loaded config: {name}")

    def delete_config(self):
        name = self.cfg_combo.currentText()
        if name in self.configs and name != "default":
            del self.configs[name]; self.save_configs()
            self.cfg_combo.clear(); self.cfg_combo.addItems(self.configs.keys())
            self.log(f"Deleted: {name}")

    def update_ui(self): pass
    def closeEvent(self, event):
        self.disconnect()
        self.settings.setValue("scale", self.scale_percent)
        self.settings.setValue("dark_mode", self.dark_mode)
        event.accept()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = GCSWindow()
    win.show()
    sys.exit(app.exec_())